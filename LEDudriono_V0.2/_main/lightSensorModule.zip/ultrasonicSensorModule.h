// ultrasonicSensorModule.h - Ultrasonic Sensor Module Header

#ifndef ULTRASONIC_SENSOR_MODULE_H
#define ULTRASONIC_SENSOR_MODULE_H

void initUltrasonicSensors();
long readUltrasonicDistance(int sensorIndex);

#endif
