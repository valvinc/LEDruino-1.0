// sensorLedManager.h - Sensor and LED Manager Header

#ifndef SENSOR_LED_MANAGER_H
#define SENSOR_LED_MANAGER_H

void initSensorsAndLEDs();
void updateSensorsAndLEDs();

#endif
